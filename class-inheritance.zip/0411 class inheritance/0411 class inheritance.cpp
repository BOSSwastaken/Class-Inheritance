// branch for polymorphism 
// virtual functions 

#include <iostream>
#include "Vehicle.h"
#include "utils.h"
#include "Car.h"
#include "EV_Car.h"


int main()
{
	Vehicle v1; 
	v1.setCode("E46"); 
	v1.setMake("bmw"); 
	v1.setModel("325i"); 

	Car c1; 

	//print(v1); 

	//print(c1);		// ?? 

	//c1.printCar(); 

	//c1.printVehicle();					// from Car class
	//c1.Car::printVehicle();				// from Car class
	//c1.Vehicle::printVehicle();		// from Vehicle class 

	EV_Car ev1; 
	ev1.charge();
	//ev1.Car::printVehicle(); 
	//ev1.Vehicle::printVehicle(); 
	//ev1.printCar();

	print(v1);
	print(c1);
	print(ev1);

	//v1 = c1; 
	//v1 = ev1; 
	//c1 = v1; 
	//ev1 = c1; 

}
