#pragma once

#include <string>

class Vehicle
{
private: 
	std::string _code; 
protected: 
	std::string _make; 
	std::string _model; 
public: 
	Vehicle() = default; 
	Vehicle(std::string code, std::string make, std::string model)
		: _code{ code }, _make{ make }, _model{ model } {} 

	std::string getCode() const; 
	std::string getMake() const; 
	std::string getModel() const; 

	void setCode(std::string code); 
	void setMake(std::string make); 
	void setModel(std::string model);

	void printVehicle() const;
};

