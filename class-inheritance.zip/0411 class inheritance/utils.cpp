#include "utils.h"
#include <iostream>

void print(const Vehicle& v)
{
	std::cout << v.getCode() << std::endl;
	std::cout << v.getMake() << std::endl;
	std::cout << v.getModel() << std::endl;
}
