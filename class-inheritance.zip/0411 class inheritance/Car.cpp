#include "Car.h"
#include <iostream>

Car::Car()
	: Vehicle("Gen 4", "Lexus", "GS 350"), _trim{ "AWD" }, _color{"Nebular gray"}
{
	//_code = "Gen 5";	// private members from base class cannot be accessed by child class 

	this->_make = "Toyota";		// protected members from base class can be accessed by child class. 
	Vehicle::_model = "Crown";	// another way to access inherited members from base class (by using scope)
}

Car::Car(std::string code, std::string make, std::string model, std::string trim, std::string color)
	: Vehicle(code, make, model), _trim{ trim }, _color{color}
{
}

void Car::tune()
{
	//_code = "super cool code";
	_make = "GR Toyota"; 
	_model = "i6 supra"; 
	_trim = "super cool trim"; 
	_color = "flash red"; 
}

void Car::printCar() const
{
	// call printVehicle from parent class
	//printVehicle(); 

	// print new variables in Car class
	std::cout << "printCar from Car object." << std::endl;

}

void Car::printVehicle() const
{
	std::cout << "printVehicle() called from Car object." << std::endl;
}


