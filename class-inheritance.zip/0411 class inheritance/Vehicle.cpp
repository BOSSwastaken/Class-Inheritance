#include "Vehicle.h"
#include <iostream>

std::string Vehicle::getCode() const
{
	return this->_code;
}

std::string Vehicle::getMake() const
{
	return this->_make;
}

std::string Vehicle::getModel() const
{
	return this->_model;
}

void Vehicle::setCode(std::string code)
{
	this->_code = code; 
}

void Vehicle::setMake(std::string make)
{
	this->_make = make; 
}

void Vehicle::setModel(std::string model)
{
	this->_model = model; 
}

void Vehicle::printVehicle() const
{
	std::cout << "printVehicle() called from Vehicle object." << std::endl;
}
