#pragma once

#include "Vehicle.h"

void print(const Vehicle& v); 
