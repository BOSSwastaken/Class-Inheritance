#pragma once
#include "Car.h"

class EV_Car : public Car
{
protected:
	double _batteryCapacity = 80; 
	double _chargeSpeed = 150; 
public: 
	EV_Car() = default; 
	void charge(); 
	void uncharge(); 
};

