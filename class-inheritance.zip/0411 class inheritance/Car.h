#pragma once

#include "Vehicle.h"

class Car : public Vehicle
{
protected:
	std::string _trim; 
	std::string _color;
public: 
	Car(); 
	Car(std::string code, std::string make, std::string model, std::string trim, std::string color); 

	void tune(); 

	void printCar() const; 

	// redefine printVehicle function here 
	void printVehicle() const;

};

