#include "EV_Car.h"

void EV_Car::charge()
{
	_make = "Lucid"; 
	_model = "Air"; 
}

void EV_Car::uncharge()
{
}
